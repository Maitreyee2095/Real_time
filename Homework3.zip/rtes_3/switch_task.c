//*****************************************************************************
//
// switch_task.c - A simple switch task to process the buttons.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "drivers/buttons.h"
#include "utils/uartstdio.h"
#include "switch_task.h"
#include "led_task.h"
#include "priorities.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "time.h"
//*****************************************************************************
//
// The stack size for the display task.
//
//*****************************************************************************
#define SWITCHTASKSTACKSIZE        128         // Stack size in words
//extern int32_t fibo_time;

extern xSemaphoreHandle g_pUARTSemaphore;
extern xSemaphoreHandle g_Task2Semaphore;
extern void calculateFibonacciseries( uint32_t numbers, uint32_t iterations );
extern uint32_t Task2Flag;
extern portTickType ui32WakeTime2;
portTickType start_time;
portTickType end_time;
//*****************************************************************************
//
// This task reads the buttons' state and passes this information to LEDTask.
//
//*****************************************************************************
static void
SwitchTask(void *pvParameters)
{
  //int num_iterations= 20/fibo_time;

    while(1){
        if( Task2Flag == 1)
        {
    //        if(xSemaphoreTake(g_Task1Semaphore,portMAX_DELAY== pdTRUE))
    //                {
            xSemaphoreTake(g_Task2Semaphore,portMAX_DELAY);
            Task2Flag=0;
            UARTprintf("%d Signaled  TAsk 2 \n", ui32WakeTime2/portTICK_PERIOD_MS);
            xSemaphoreGive(g_Task2Semaphore);
            start_time=xTaskGetTickCount();
            calculateFibonacciseries(50,89990);
            end_time=xTaskGetTickCount();
            int32_t elapsed=end_time-start_time;
            UARTprintf("%d Elapsed time TAsk 2 \n",elapsed/portTICK_PERIOD_MS);
                        //xSemaphoreGive(g_Task1Semaphore);

            vTaskDelay(1000);
    //                }
    //        else{
    //            ;
    //        }

        }
    }
}

//*****************************************************************************
//
// Initializes the switch task.
//
//*****************************************************************************
uint32_t
SwitchTaskInit(void)
{


    //
    // Create the switch task.
    //
    if(xTaskCreate(SwitchTask, (const portCHAR *)"Switch",
                   SWITCHTASKSTACKSIZE, NULL, tskIDLE_PRIORITY +
                   PRIORITY_SWITCH_TASK, NULL) != pdTRUE)
    {
        return(1);
    }

    //
    // Success.
    //
    return(0);
}
